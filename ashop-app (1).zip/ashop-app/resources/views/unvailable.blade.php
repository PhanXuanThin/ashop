@extends('layouts.master')

@section('content')

    {{-- <h1>The Coutry is not supported !</h1> --}}
    <h1>You Dont have the permission to access !</h1>

@endsection
