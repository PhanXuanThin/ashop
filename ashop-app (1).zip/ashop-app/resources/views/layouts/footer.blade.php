<div class="container">
    <div class="row">
      <div class="col">
        <h4>Thông tin liên hệ</h4>
        <p>Địa chỉ: 123 Đường ABC, Quận XYZ, Thành phố</p>
        <p>Email: info@example.com</p>
        <p>Điện thoại: 0123 456 789</p>
      </div>
      <div class="col">
        <h4>Liên kết nhanh</h4>
        <ul>
          <li><a href="/">Trang chủ</a></li>
          <li><a href="/gioi-thieu">Giới thiệu</a></li>
          <li><a href="/lien-he">Liên hệ</a></li>
        </ul>
      </div>
      <div class="col">
        <h4>Theo dõi chúng tôi</h4>
        <ul class="social-media">
          <li><a href="#"><i class="fab fa-facebook"></i></a></li>
          <li><a href="#"><i class="fab fa-twitter"></i></a></li>
          <li><a href="#"><i class="fab fa-instagram"></i></a></li>
        </ul>
      </div>
    </div>
    <div class="copyright">
      <p>&copy; 2023 Tên công ty. Bảo lưu mọi quyền.</p>
    </div>
  </div>
