<div>
    <!-- Simplicity is the consequence of refined emotions. - Jean D'Alembert -->
    <button>Button 2</button>
</div>
