<div class="col-md-4 mb-2">
    <div class="card">
        <div class="card-body">
            <h4>{{ $title }}</h4>
            <p>{{ $description }}</p>
        </div>
    </div>
</div>
