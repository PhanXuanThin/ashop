@extends('layouts.master')

@section('content')

<main role="main" class= "container">
    {{-- <p>{{ $home }}</p> --}}

    {{-- <div class="row mt-5">
    @foreach ($blogs as $blog)
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h2>{{ $blog['title'] }}</h2>
                    <p>{{ $blog['body'] }}</p>
                </div>
            </div>
        </div>
    @endforeach
    </div> --}}
</main>

@endsection
