<header class="header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-3 col-lg-2">
                <div class="header__logo">
                    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo"></a>
                </div>
            </div>
            <div class="col-xl-6 col-lg-7">
                <nav class="header__menu">
                    <ul>
                        <li class="<?php echo e(Request::is('/') ? 'active' : ''); ?>"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li><a href="#">Women’s</a></li>
                        <li><a href="#">Men’s</a></li>
                        <li class="<?php echo e(Request::is('shop') ? 'active' : ''); ?>"><a href="<?php echo e(url('/shop')); ?>">Shop</a></li>
                        <li>
                            <a href="#">Pages</a>
                            <ul class="dropdown">
                                <li class="<?php echo e(Request::is('product-details') ? 'active' : ''); ?>"><a href="<?php echo e(url('/product-details')); ?>">Product Details</a></li>
                                <li class="<?php echo e(Request::is('shop-cart') ? 'active' : ''); ?>"><a href="<?php echo e(url('/shop-cart')); ?>">Shop Cart</a></li>
                                <li class="<?php echo e(Request::is('checkout') ? 'active' : ''); ?>"><a href="<?php echo e(url('/checkout')); ?>">Checkout</a></li>
                                <li class="<?php echo e(Request::is('blog-details') ? 'active' : ''); ?>"><a href="<?php echo e(url('/blog-details')); ?>">Blog Details</a></li>
                            </ul>
                        </li>
                        <li class="<?php echo e(Request::is('blog') ? 'active' : ''); ?>"><a href="<?php echo e(url('/blog')); ?>">Blog</a></li>
                        <li class="<?php echo e(Request::is('contact') ? 'active' : ''); ?>"><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
                    </ul>
                </nav>
            </div>
            <div class="col-lg-3">
                <div class="header__right">
                    <div class="header__right__auth">
                        <?php if(auth()->guard()->guest()): ?>
                            <a href="<?php echo e(route('login')); ?>">Login</a>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php else: ?>
                            <a href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                               Logout
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        <?php endif; ?>
                    </div>
                    <ul class="header__right__widget">
                        <li><span class="icon_search search-switch"></span></li>
                        <li>
                            <a href="#">
                                <span class="icon_heart_alt"></span>
                                <div class="tip">2</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="icon_bag_alt"></span>
                                <div class="tip">2</div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="canvas__open">
            <i class="fa fa-bars"></i>
        </div>
    </div>
</header>
<?php /**PATH /var/www/html/ashop-app/resources/views/partials/header.blade.php ENDPATH**/ ?>